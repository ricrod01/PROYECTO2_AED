import networkx as nx
import tkinter as tk
from tkinter import filedialog

# Función para cargar el grafo desde un archivo de texto
def cargar_grafo(path):
    G = nx.DiGraph()  # Crear grafo dirigido vacío
    seccion = None    # Variable para rastrear la sección actual en el archivo

    with open(path, "r", encoding="utf-8") as f:
        for linea in f:
            linea = linea.strip()  # Quitar espacios en blanco al inicio y fin
            if not linea or linea.startswith("//"):  # Ignorar líneas vacías o comentarios //
                continue
            if linea.startswith("#"):  # Detectar encabezados de sección (#Usuarios, #Peliculas, etc.)
                if "Usuarios" in linea:
                    seccion = "usuarios"
                elif "Peliculas" in linea:
                    seccion = "peliculas"
                elif "RelacionesUsuarioUsuario" in linea:
                    seccion = "rel_usu_usu"
                elif "RelacionesUsuarioPelicula" in linea:
                    seccion = "rel_usu_peli"
                else:
                    seccion = None
                continue

            # Procesar línea según la sección actual
            if seccion == "usuarios":
                usuario, genero = linea.split()
                G.add_node(usuario, tipo="usuario", genero=genero)
            elif seccion == "peliculas":
                peli, genero, puntuacion = linea.split()
                puntuacion = float(puntuacion)
                G.add_node(peli, tipo="pelicula", genero=genero, puntuacion=puntuacion)
            elif seccion == "rel_usu_usu":
                u1, u2, peso = linea.split()
                peso = float(peso)
                G.add_edge(u1, u2, tipo="AMIGO_DE", peso=peso)
            elif seccion == "rel_usu_peli":
                usuario, peli, peso = linea.split()
                peso = float(peso)
                G.add_edge(usuario, peli, tipo="VIO", peso=peso)

    return G  # Devuelve el grafo construido

# Función para recomendar películas a un usuario dado
def recomendar_peliculas(usuario, G, top_k=3):
    if usuario not in G.nodes:
        print(f"Usuario {usuario} no encontrado.")
        return []

    genero_fav = G.nodes[usuario]['genero']  # Obtener género favorito del usuario

    # Obtener películas que el usuario ya vio (aristas "VIO")
    vistos = {v for u, v, d in G.edges(usuario, data=True) if d['tipo'] == "VIO"}

    # Obtener amigos del usuario (aristas "AMIGO_DE")
    amigos = {v for u, v, d in G.edges(usuario, data=True) if d['tipo'] == "AMIGO_DE"}

    candidatas = []
    for nodo in G.nodes:
        # Considerar solo nodos que sean películas
        if G.nodes[nodo].get("tipo") == "pelicula":
            # Solo películas no vistas por el usuario y que sean del género favorito
            if nodo not in vistos and G.nodes[nodo]['genero'] == genero_fav:
                score_base = G.nodes[nodo]['puntuacion']

                peso_amigos = 0
                # Sumar pesos de visualización de amigos para esta película
                for amigo in amigos:
                    if G.has_edge(amigo, nodo) and G[amigo][nodo]["tipo"] == "VIO":
                        peso_amigos += G[amigo][nodo]["peso"]

                puntuacion_final = score_base + peso_amigos
                # Solo agregar si al menos un amigo vio la película
                if peso_amigos > 0:
                    candidatas.append((nodo, puntuacion_final))

    # Ordenar candidatas por puntuación final descendente
    candidatas.sort(key=lambda x: x[1], reverse=True)
    return candidatas[:top_k]  # Devolver las top_k recomendaciones

# Función para abrir un diálogo gráfico y seleccionar el archivo de datos
def seleccionar_archivo():
    root = tk.Tk()
    root.withdraw()  # Ocultar ventana principal de Tkinter
    ruta = filedialog.askopenfilename(
        title="Selecciona el archivo de datos del grafo",
        filetypes=[("Archivos de texto", "*.txt"), ("Todos los archivos", "*.*")]
    )
    return ruta  # Retorna la ruta del archivo seleccionado

# Función principal que ejecuta el flujo del programa
def main():
    print("Selecciona el archivo con los datos del grafo:")
    archivo = seleccionar_archivo()
    if not archivo:
        print("No seleccionaste ningún archivo.")
        return

    G = cargar_grafo(archivo)  # Cargar grafo desde el archivo

    # Bucle para solicitar usuarios y mostrar recomendaciones hasta que se escriba "salir"
    while True:
        usuario = input("\nIngresa un usuario (Ejemplo: U1) o 'salir' para terminar: ").strip().upper()
        if usuario == "SALIR":
            print("Saliendo...")
            break

        recomendaciones = recomendar_peliculas(usuario, G)
        if recomendaciones:
            print(f"Recomendaciones para {usuario}:")
            for peli, score in recomendaciones:
                print(f"  - {peli} (puntaje: {score:.3f})")
        else:
            print(f"No hay recomendaciones para {usuario}.")

# Punto de entrada del script
if __name__ == "__main__":
    main()
